function stringsContainingCharacter(arr, char) {
    return arr.filter(str => str.includes(char));
}  
const strings = ["apple", "banana", "orange", "kiwi", "strawberry"];
const character = "n";
const result = stringsContainingCharacter(strings, character);
console.log(result);
