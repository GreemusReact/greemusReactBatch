function capitalizeFLetter() {
    let string = 'manikanta';
    console.log(string[0].toUpperCase() +
        string.slice(1));
}
capitalizeFLetter()
