// array of web technologies
const webTechs = ['HTML', 'CSS', 'JS', 'React', 'Redux', 'Node', 'MongDB'] 

// print the final array
console.log('web technologies :' , webTechs)
console.log('Number of web technologies :', webTechs.length)