function countOccurrences(arr) {
    const occurrences = {};
    

    arr.forEach(item => {
        if (occurrences[item]) {
            occurrences[item]++;
        } else {
            occurrences[item] = 1;
        }
    });
    
    return occurrences;
}

const strings = ['a', 'b', 'c', 'a', 'c', 'p', 'b'];
const occurrences = countOccurrences(strings);
console.log(occurrences);
