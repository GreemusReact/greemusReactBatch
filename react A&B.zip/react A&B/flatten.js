function flattenArray(arr) {
    return arr.reduce((flatArray, item) => {
        if (Array.isArray(item)) {
            return flatArray.concat(flattenArray(item));
        } else {
            return flatArray.concat(item);
        }
    }, []);
} 
const nestedArray = [1, [2, 3], [4, [5, 6]], [2, 5, 7]];
const flatArray = flattenArray(nestedArray);
console.log(flatArray);
