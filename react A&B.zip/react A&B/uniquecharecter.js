function findUniqueCharacters(str) {
    const uniqueCharacters = [];

    for (let char of str) {
        if (!uniqueCharacters.includes(char)) {

            uniqueCharacters.push(char);
        }
    }

    return uniqueCharacters;
}

const uniqueChars = findUniqueCharacters("devikavenu");
console.log(uniqueChars); 
