function convertToUpperCase(arr) {
    return arr.map(str => str.toUpperCase());
}
const strings = ['mani', 'harshi', 'ammu', 'dhevika'];
const upperCaseStrings = convertToUpperCase(strings);
console.log(upperCaseStrings); 