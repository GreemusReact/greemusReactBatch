// Create an array of 5 numbers
let numbers = [1, 2, 3, 4, 5];

// Add a number to the end of the array
numbers.push(6);

// Remove the first number from the array
numbers.shift();

// Print the final array
console.log(numbers);
