let arr = [8, 2, 3, 4, 2, 3, 5, 6];

function removeDuplicates(arr) {
    return arr.filter((item,
        index) => arr.indexOf(item) === index);
}
console.log(removeDuplicates(arr));