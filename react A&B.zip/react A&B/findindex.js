function findIndex(arr, str) {
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] === str) {
            return i; 
        }
    }
    return -1;
}

const strings = ['harshi', 'devika', 'subbu', 'dheeraj', 'mani'];
const index = findIndex(strings, 'devika');
console.log(index);
