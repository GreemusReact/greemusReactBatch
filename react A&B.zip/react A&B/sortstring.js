const webTechs = ['HTML', 'CSS', 'JavaScript', 'React', 'Redux', 'Node', 'MongoDB' ]
  
  webTechs.sort()
  console.log(webTechs)