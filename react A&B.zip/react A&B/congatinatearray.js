function concatenateStrings(arr) {
    return arr.join('');
}

// Example usage:
const strings = ["apple", "banana", "orange", "kiwi", "strawberry"];
const concatenatedString = concatenateStrings(strings);
console.log(concatenatedString);
  