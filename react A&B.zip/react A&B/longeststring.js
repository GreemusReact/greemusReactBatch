const strings = ["apple", "banana", "orange", "kiwi", "strawberry"];
const longest = findLongestString(strings);
function findLongestString(arr) {
    let longestString = "";
    for (let str of arr) {
        if (str.length > longestString.length) { 
            longestString = str;
        }
    }
    return longestString;
}

console.log(longest);
