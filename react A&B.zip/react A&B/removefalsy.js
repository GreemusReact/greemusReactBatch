function removeFalsyValues(arr) {
    return arr.filter(value => !!value);
}
const mixedArray = [false, 0, "", null, undefined, NaN, 42, "hello"];
const filteredArray = removeFalsyValues(mixedArray);
console.log(filteredArray);
